//Problem One -- create a deck of cards, shuffle the cards, then show the first five cards "drawn"
function card(value, suit) {
	this.value = value;
	this.suit = suit;
}

function deck() {
	this.value = ['Ace', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King'];
	this.suits = ['Hearts','Diamonds','Spades','Clubs'];
	let cards = [];
    for(let s = 0; s < this.suits.length; s++) {
        for(let v = 0; v < this.value.length; v++) {
            cards.push(new card(this.value[v], this.suits[s]));
        }
    }
    return cards;
}

let myDeck = new deck();
console.log(myDeck);


function shuffle(dlength) {
	for(var j, x, i = dlength.length; i; j = parseInt(Math.random() * i), x = dlength[--i], dlength[i] = dlength[j], dlength[j] = x);
	return dlength;
};

myDeck = shuffle(myDeck);
console.log(myDeck);

function giveHand() {
    for(let i=0; i<5; i++) {
        console.log(`${myDeck[i].value} of ${myDeck[i].suit}`);
    }
}
giveHand();

//Problem Two -- Check to see if a given variable is Null or Undefined
function checkVariable(variable) {
    if(variable == null){
        console.log(`The variable is null or undefined`);
    }
    else {console.log(`the variable is NOT null or undefined`);}
}

checkVariable(1);
checkVariable();

//problem 3 -- show the parameters of the function in the console log.
function takeasParameter(a,b) {
    if(a>b){
        console.log(`the first number is ${arguments[0]}`);
        console.log(`the second number is ${arguments[1]}`);
        console.log(`the first number is larger than the second number`);
    }
}
takeasParameter(3,2);

//Problem Four -- Merge these Objects into one Object
const games = [
    "Total War: Warhammer III",
    "Factorio",
    "Exanima",
    "Minecraft",
    "Factorio"
];
const movies = [
    "EEAAO",
    "Portrait of a Lady on Fire",
    "Blade Runner"
];
let gamesandmovies = [...games, ...movies];

console.log(gamesandmovies);

//problem 5 goes here.

//problem 6 goes here.

//Problem Seven -- only call out the lasName from the items below.
const fullNames = [
    {firstName: "Bart", lastName: "Cranberry"},
    {firstName: "Candy", lastName: "Christmas"},
    {firstName: "Aerith", lastName: "Johnson"}
];

fullNames.forEach((n) => {
    console.log(`${n.lastName}`);
});

//Problem Eight -- sort the listed items by their Age.
const colorandShape = [
    {Color: "Red", Shape: "Round", Age: 22},
    {Color: "Blue", Shape: "Square", Age: 5},
    {Color: "Yellow", Shape: "Triangle", Age: 10},
    {Color: "Blue", Shape: "Round", Age: 34},
    {Color: "Red", Shape: "Triangle", Age: 7}
];

function compareAge(a, b) {
    return a.Age-b.Age;
}
console.log(colorandShape.sort(compareAge));

//Problem Nine -- pull a wanted properties and put them an a new array.
function extractValue(arr, prop) {

    let extractedValue = [];

    for (let i=0; i < arr.length ; ++i) {
        extractedValue.push(arr[i][prop]);
    }
    return extractedValue;
}

const result = extractValue(colorandShape, "Shape");
console.log(result);

//Problem Ten -- Check an array for a specific Value
const numberArray = ["2", "3", "4", "6", 6];
const checkforNumber = numberArray.includes("6");
console.log(numberArray.includes("6"));
console.log(checkforNumber);